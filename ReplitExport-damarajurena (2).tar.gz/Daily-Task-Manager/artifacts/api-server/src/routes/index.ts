import { Router, type IRouter } from "express";
import healthRouter from "./health";
import tasksRouter from "./tasks";
import notesRouter from "./notes";
import aiRouter from "./ai";
import transcriptRouter from "./transcript";

const router: IRouter = Router();

router.use(healthRouter);
router.use(tasksRouter);
router.use(notesRouter);
router.use(aiRouter);
router.use(transcriptRouter);

export default router;
