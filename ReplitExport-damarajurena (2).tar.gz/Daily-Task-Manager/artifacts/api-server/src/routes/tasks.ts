import { Router } from "express";
import { db } from "@workspace/db";
import { tasksTable } from "@workspace/db";
import { eq, and, lt, sql } from "drizzle-orm";
import {
  ListTasksQueryParams,
  CreateTaskBody,
  UpdateTaskParams,
  UpdateTaskBody,
  DeleteTaskParams,
  GetTaskParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/tasks/weekly-stats", async (req, res) => {
  const now = new Date();
  const dayOfWeek = now.getDay(); // 0 = Sunday
  const monday = new Date(now);
  monday.setDate(now.getDate() - ((dayOfWeek + 6) % 7));

  const days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);
    return d.toISOString().split("T")[0];
  });

  const labels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

  const rows = await db
    .select({
      date: tasksTable.date,
      total: sql<number>`count(*)::int`,
      completed: sql<number>`count(*) filter (where ${tasksTable.completed} = true)::int`,
    })
    .from(tasksTable)
    .where(
      sql`${tasksTable.date} >= ${days[0]} and ${tasksTable.date} <= ${days[6]}`
    )
    .groupBy(tasksTable.date);

  const byDate = Object.fromEntries(rows.map((r) => [r.date, r]));

  const stats = days.map((date, i) => ({
    date,
    dayLabel: labels[i],
    total: byDate[date]?.total ?? 0,
    completed: byDate[date]?.completed ?? 0,
  }));

  res.json(stats);
});

router.get("/tasks/summary", async (req, res) => {
  const today = new Date().toISOString().split("T")[0];

  const [totalRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(tasksTable);

  const [completedRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(tasksTable)
    .where(eq(tasksTable.completed, true));

  const [pendingRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(tasksTable)
    .where(eq(tasksTable.completed, false));

  const [todayTotalRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(tasksTable)
    .where(eq(tasksTable.date, today));

  const [todayCompletedRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(tasksTable)
    .where(and(eq(tasksTable.date, today), eq(tasksTable.completed, true)));

  const [overdueRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(tasksTable)
    .where(and(lt(tasksTable.date, today), eq(tasksTable.completed, false)));

  res.json({
    total: totalRow.count,
    completed: completedRow.count,
    pending: pendingRow.count,
    todayTotal: todayTotalRow.count,
    todayCompleted: todayCompletedRow.count,
    overdueCount: overdueRow.count,
  });
});

router.get("/tasks", async (req, res) => {
  const parsed = ListTasksQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid query parameters" });
    return;
  }

  const { date, completed } = parsed.data;
  const conditions = [];

  if (date !== undefined) {
    conditions.push(eq(tasksTable.date, date));
  }
  if (completed !== undefined) {
    conditions.push(eq(tasksTable.completed, completed));
  }

  const tasks =
    conditions.length > 0
      ? await db.select().from(tasksTable).where(and(...conditions))
      : await db.select().from(tasksTable);

  res.json(
    tasks.map((t) => ({
      ...t,
      createdAt: t.createdAt.toISOString(),
    }))
  );
});

router.post("/tasks", async (req, res) => {
  const parsed = CreateTaskBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const { title, date, priority = "medium", notes } = parsed.data;

  const [task] = await db
    .insert(tasksTable)
    .values({ title, date, priority, notes: notes ?? null })
    .returning();

  res.status(201).json({ ...task, createdAt: task.createdAt.toISOString() });
});

router.get("/tasks/:id", async (req, res) => {
  const parsed = GetTaskParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }

  const [task] = await db
    .select()
    .from(tasksTable)
    .where(eq(tasksTable.id, parsed.data.id));

  if (!task) {
    res.status(404).json({ error: "Task not found" });
    return;
  }

  res.json({ ...task, createdAt: task.createdAt.toISOString() });
});

router.patch("/tasks/:id", async (req, res) => {
  const paramParsed = UpdateTaskParams.safeParse({ id: Number(req.params.id) });
  if (!paramParsed.success) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }

  const bodyParsed = UpdateTaskBody.safeParse(req.body);
  if (!bodyParsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const updates: Partial<typeof tasksTable.$inferInsert> = {};
  const { title, date, completed, priority, notes } = bodyParsed.data;
  if (title !== undefined) updates.title = title;
  if (date !== undefined) updates.date = date;
  if (completed !== undefined) updates.completed = completed;
  if (priority !== undefined) updates.priority = priority;
  if (notes !== undefined) updates.notes = notes;

  const [task] = await db
    .update(tasksTable)
    .set(updates)
    .where(eq(tasksTable.id, paramParsed.data.id))
    .returning();

  if (!task) {
    res.status(404).json({ error: "Task not found" });
    return;
  }

  res.json({ ...task, createdAt: task.createdAt.toISOString() });
});

router.delete("/tasks/:id", async (req, res) => {
  const parsed = DeleteTaskParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }

  await db.delete(tasksTable).where(eq(tasksTable.id, parsed.data.id));
  res.status(204).send();
});

export default router;
