import { Router } from "express";
import { db } from "@workspace/db";
import { notesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { CreateNoteBody, UpdateNoteBody, UpdateNoteParams } from "@workspace/api-zod";

const router = Router();

function serializeNote(note: typeof notesTable.$inferSelect) {
  return {
    ...note,
    createdAt: note.createdAt.toISOString(),
    updatedAt: note.updatedAt.toISOString(),
  };
}

router.get("/notes", async (_req, res) => {
  const notes = await db.select().from(notesTable).orderBy(notesTable.updatedAt);
  res.json(notes.map(serializeNote));
});

router.post("/notes", async (req, res) => {
  const parsed = CreateNoteBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }
  const [note] = await db.insert(notesTable).values(parsed.data).returning();
  res.status(201).json(serializeNote(note));
});

router.patch("/notes/:id", async (req, res) => {
  const paramParsed = UpdateNoteParams.safeParse({ id: Number(req.params.id) });
  if (!paramParsed.success) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }
  const bodyParsed = UpdateNoteBody.safeParse(req.body);
  if (!bodyParsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }
  const [note] = await db
    .update(notesTable)
    .set({ ...bodyParsed.data, updatedAt: new Date() })
    .where(eq(notesTable.id, paramParsed.data.id))
    .returning();
  if (!note) {
    res.status(404).json({ error: "Note not found" });
    return;
  }
  res.json(serializeNote(note));
});

router.delete("/notes/:id", async (req, res) => {
  const parsed = UpdateNoteParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }
  await db.delete(notesTable).where(eq(notesTable.id, parsed.data.id));
  res.status(204).send();
});

export default router;
