import { Router } from "express";
import { YoutubeTranscript } from "youtube-transcript";

const router = Router();

function extractVideoId(input: string): string | null {
  try {
    const url = new URL(input);
    if (url.hostname === "youtu.be") return url.pathname.slice(1).split("?")[0];
    if (url.hostname.includes("youtube.com")) {
      const v = url.searchParams.get("v");
      if (v) return v;
      const match = url.pathname.match(/\/embed\/([^/?]+)/);
      if (match) return match[1];
    }
  } catch {
    // not a URL — treat as raw video ID
    if (/^[a-zA-Z0-9_-]{11}$/.test(input.trim())) return input.trim();
  }
  return null;
}

router.post("/transcript", async (req, res) => {
  const { url } = req.body as { url?: string };

  if (!url || typeof url !== "string" || !url.trim()) {
    res.status(400).json({ error: "Please provide a YouTube URL." });
    return;
  }

  const videoId = extractVideoId(url.trim());
  if (!videoId) {
    res.status(400).json({ error: "Could not find a valid YouTube video ID in that URL." });
    return;
  }

  try {
    const entries = await YoutubeTranscript.fetchTranscript(videoId);
    const text = entries.map((e) => e.text).join(" ").replace(/\s+/g, " ").trim();

    if (!text) {
      res.status(404).json({ error: "No transcript found for this video. It may have captions disabled." });
      return;
    }

    res.json({ transcript: text, videoId });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    req.log.warn({ videoId, err: msg }, "Transcript fetch failed");

    if (msg.includes("disabled") || msg.includes("No transcript")) {
      res.status(404).json({ error: "This video doesn't have a transcript available. Try a video with auto-generated or manual captions." });
    } else {
      res.status(502).json({ error: "Could not fetch the transcript. The video may be private, age-restricted, or unavailable." });
    }
  }
});

export default router;
