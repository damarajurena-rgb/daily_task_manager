import { useState, useEffect, useRef, useCallback } from "react";
import { Layout } from "@/components/layout";
import { Timer, RotateCcw, Play, Pause } from "lucide-react";

type Phase = "focus" | "break";

const PRESETS: { label: string; minutes: number; phase: Phase }[] = [
  { label: "Focus", minutes: 25, phase: "focus" },
  { label: "Short break", minutes: 5, phase: "break" },
  { label: "Long break", minutes: 15, phase: "break" },
];

function formatTime(seconds: number) {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

function playSound(type: "start" | "stop" | "break" | "complete") {
  try {
    const ctx = new AudioContext();
    const gain = ctx.createGain();
    gain.connect(ctx.destination);

    const play = (freq: number, startAt: number, duration: number, vol = 0.35) => {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.connect(g);
      g.connect(ctx.destination);
      osc.type = "sine";
      osc.frequency.setValueAtTime(freq, ctx.currentTime + startAt);
      g.gain.setValueAtTime(vol, ctx.currentTime + startAt);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + startAt + duration);
      osc.start(ctx.currentTime + startAt);
      osc.stop(ctx.currentTime + startAt + duration);
    };

    if (type === "start") {
      // Two ascending tones — ready, go
      play(440, 0, 0.15);
      play(660, 0.18, 0.2);
    } else if (type === "stop") {
      // Single soft descending tone
      play(440, 0, 0.12);
      play(330, 0.14, 0.18);
    } else if (type === "break") {
      // Gentle three-note chime — relax
      play(528, 0, 0.25, 0.3);
      play(660, 0.28, 0.25, 0.25);
      play(792, 0.56, 0.4, 0.2);
    } else {
      // Complete — warm bell chord
      play(440, 0, 0.6);
      play(550, 0.05, 0.6, 0.25);
      play(660, 0.1, 0.8, 0.2);
    }

    gain.disconnect();
  } catch {}
}

export function TimerPage() {
  const [totalSeconds, setTotalSeconds] = useState(25 * 60);
  const [remaining, setRemaining] = useState(25 * 60);
  const [running, setRunning] = useState(false);
  const [phase, setPhase] = useState<Phase>("focus");
  const [customMinutes, setCustomMinutes] = useState("");
  const [done, setDone] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const progress = totalSeconds > 0 ? 1 - remaining / totalSeconds : 1;
  const radius = 120;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference * (1 - progress);

  const stop = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }, []);

  const tick = useCallback(() => {
    setRemaining((prev) => {
      if (prev <= 1) {
        stop();
        setRunning(false);
        setDone(true);
        playSound("complete");
        return 0;
      }
      return prev - 1;
    });
  }, [stop]);

  useEffect(() => {
    if (running) {
      intervalRef.current = setInterval(tick, 1000);
    } else {
      stop();
    }
    return stop;
  }, [running, tick, stop]);

  function applyPreset(minutes: number, p: Phase) {
    stop();
    setRunning(false);
    setDone(false);
    setPhase(p);
    setTotalSeconds(minutes * 60);
    setRemaining(minutes * 60);
    setCustomMinutes("");
    if (p === "break") playSound("break");
  }

  function applyCustom() {
    const mins = parseInt(customMinutes, 10);
    if (!mins || mins < 1 || mins > 180) return;
    stop();
    setRunning(false);
    setDone(false);
    setPhase("focus");
    setTotalSeconds(mins * 60);
    setRemaining(mins * 60);
  }

  function reset() {
    stop();
    setRunning(false);
    setDone(false);
    setRemaining(totalSeconds);
  }

  function toggleRun() {
    if (done) return;
    setRunning((r) => {
      playSound(r ? "stop" : "start");
      return !r;
    });
  }

  const ringColor = phase === "focus" ? "hsl(var(--primary))" : "hsl(160 40% 50%)";
  const ringBg = phase === "focus" ? "hsl(var(--primary) / 0.12)" : "hsl(160 40% 50% / 0.12)";

  return (
    <Layout>
      <header className="mb-10">
        <div className="flex items-center gap-3 mb-2">
          <Timer className="w-6 h-6 text-primary" />
          <h1 className="text-4xl md:text-5xl font-serif text-foreground">Study Timer</h1>
        </div>
        <p className="text-muted-foreground">Stay focused, then rest.</p>
      </header>

      <div className="flex flex-col items-center gap-10">
        {/* Preset buttons */}
        <div className="flex gap-3 flex-wrap justify-center">
          {PRESETS.map((p) => (
            <button
              key={p.label}
              onClick={() => applyPreset(p.minutes, p.phase)}
              className={`px-5 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                totalSeconds === p.minutes * 60 && phase === p.phase
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "bg-muted text-muted-foreground hover:bg-muted/80 hover:text-foreground"
              }`}
            >
              {p.label} · {p.minutes}m
            </button>
          ))}
        </div>

        {/* Circular progress ring */}
        <div className="relative flex items-center justify-center">
          <svg width="300" height="300" className="-rotate-90">
            <circle
              cx="150"
              cy="150"
              r={radius}
              fill="none"
              stroke={ringBg}
              strokeWidth="12"
            />
            <circle
              cx="150"
              cy="150"
              r={radius}
              fill="none"
              stroke={ringColor}
              strokeWidth="12"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              style={{ transition: running ? "stroke-dashoffset 1s linear" : "stroke-dashoffset 0.3s ease" }}
            />
          </svg>

          <div className="absolute flex flex-col items-center gap-1">
            <span
              className={`font-mono text-6xl font-light tracking-tight tabular-nums transition-colors duration-300 ${
                done ? "text-primary" : "text-foreground"
              }`}
            >
              {formatTime(remaining)}
            </span>
            <span className="text-sm text-muted-foreground uppercase tracking-widest">
              {done ? "Complete" : phase === "focus" ? "Focus" : "Break"}
            </span>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-4">
          <button
            onClick={reset}
            className="w-12 h-12 rounded-full bg-muted text-muted-foreground hover:bg-muted/80 hover:text-foreground transition-all duration-200 flex items-center justify-center"
            title="Reset"
          >
            <RotateCcw className="w-5 h-5" />
          </button>

          <button
            onClick={toggleRun}
            disabled={done}
            className={`w-20 h-20 rounded-full text-primary-foreground shadow-lg flex items-center justify-center transition-all duration-200 active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed ${
              running
                ? "bg-primary/80 hover:bg-primary/70"
                : "bg-primary hover:bg-primary/90"
            }`}
          >
            {running ? <Pause className="w-8 h-8" /> : <Play className="w-8 h-8 translate-x-0.5" />}
          </button>

          <div className="w-12 h-12" />
        </div>

        {/* Custom duration */}
        <div className="flex items-center gap-3 mt-2">
          <input
            type="number"
            min={1}
            max={180}
            placeholder="Custom minutes"
            value={customMinutes}
            onChange={(e) => setCustomMinutes(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && applyCustom()}
            className="w-40 px-4 py-2 rounded-xl bg-muted border border-border text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40"
          />
          <button
            onClick={applyCustom}
            className="px-4 py-2 rounded-xl bg-muted text-muted-foreground text-sm hover:bg-muted/80 hover:text-foreground transition-all duration-200"
          >
            Set
          </button>
        </div>

        {done && (
          <div className="animate-in fade-in zoom-in-95 duration-500 text-center">
            <p className="text-lg font-serif text-foreground mb-1">Time's up.</p>
            <p className="text-muted-foreground text-sm">Press reset to start another session.</p>
          </div>
        )}
      </div>
    </Layout>
  );
}
