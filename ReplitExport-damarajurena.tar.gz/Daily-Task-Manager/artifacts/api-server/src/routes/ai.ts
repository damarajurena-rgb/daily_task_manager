import { Router } from "express";

const router = Router();

router.post("/ai/summarize", async (req, res) => {
  const { text } = req.body as { text?: string };

  if (!text || typeof text !== "string" || !text.trim()) {
    res.status(400).json({ error: "Please provide some text to summarize." });
    return;
  }

  const baseUrl = process.env.AI_INTEGRATIONS_OPENAI_BASE_URL;
  const apiKey = process.env.AI_INTEGRATIONS_OPENAI_API_KEY;

  if (!baseUrl || !apiKey) {
    res.status(503).json({
      error:
        "AI summarization is not yet active. To enable it, verify your phone number in your Replit account settings.",
    });
    return;
  }

  const response = await fetch(`${baseUrl}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "gpt-5-mini",
      max_completion_tokens: 512,
      messages: [
        {
          role: "system",
          content:
            "You are a concise study assistant. Summarize the user's notes in 3–5 clear bullet points. Be brief and direct. Do not add preamble or closings.",
        },
        {
          role: "user",
          content: text.trim(),
        },
      ],
    }),
  });

  if (!response.ok) {
    const body = await response.text().catch(() => "");
    req.log.error({ status: response.status, body }, "AI API error");
    res.status(502).json({ error: "The AI service returned an error. Please try again." });
    return;
  }

  const data = (await response.json()) as {
    choices: { message: { content: string } }[];
  };
  const summary = data.choices?.[0]?.message?.content ?? "";
  res.json({ summary });
});

export default router;
